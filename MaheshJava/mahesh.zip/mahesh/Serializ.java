import java.io.*;
class Parent implements Serializable
{
int num1 = 18;
int num2 = 21;
}
class Serializ
{
public static void main(String[] args) throws Exception
{
Parent p1 = new Parent();

FileOutputStream fout = new FileOutputStream("mahesh.txt");
ObjectOutputStream obj = new ObjectOutputStream(fout);
obj.writeObject(p1);
System.out.println("Done with serializable, Check your folder once..!!");

FileInputStream fin = new FileInputStream("mahesh.txt");
ObjectInputStream oin = new ObjectInputStream(fin);
Parent p2 = (Parent)oin.readObject();
System.out.println(p2.num1+" "+p2.num2);
}
}
