public class NewInstanc
{
String str = "mahesh";
public static void main(String[] args)
{
Class cls = Class.forName("NewInstance");
NewInstanc obj = (NewInstanc) class.newInstance();
System.out.println(obj.str);
}
}
