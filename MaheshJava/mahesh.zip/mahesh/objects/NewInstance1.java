
public class NewInstance1
{ 
    String name = "This is Mahesh"; 
    public static void main(String[] args) 
    { 
        try
        { 
            Class cls = Class.forName("NewInstance1"); 
	    NewInstance1 obj = (NewInstance1) cls.newInstance();
            System.out.println(obj.name); 
        } 
        catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) 
        { 
            e.printStackTrace(); 
        } 
    } 
} 
