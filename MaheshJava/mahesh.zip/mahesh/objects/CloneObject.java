class CloneObject implements Cloneable
{  
int a;  
String name;  
      
CloneObject(int a,String name)
{  
this.a=a;  
this.name=name;  
}  
      
public Object clone()throws CloneNotSupportedException
{  
return super.clone();  
}  
      
public static void main(String args[])
{  
try
{  
CloneObject s1=new CloneObject(18,"mahesh");  
      
CloneObject s2=(CloneObject)s1.clone();  
      
System.out.println(s1.a+" "+s1.a);  
System.out.println(s2.name+" "+s2.name);  
      
}
catch(CloneNotSupportedException c){}  
      
}  
}  
