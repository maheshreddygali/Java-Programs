import java.io.*;  
public class CanonicalFile {  
public static void main(String[] args) 
{  
try 
{  
File file = new File("sample file.txt");  
file.createNewFile();
File f2 = file.getCanonicalFile();
System.out.println(f2); 

} 
catch (IOException e) 
{  
e.printStackTrace();  
}  
}  
}  
