import java.io.*;  
public class CanonicalPath {  
public static void main(String[] args) 
{  
try 
{  
File file = new File("sample file.txt");  
file.createNewFile();
String f2 = file.getCanonicalPath();
String path = file.getAbsolutePath();  
System.out.println(f2); 
System.out.println(path);
} 
catch (IOException e) 
{  
e.printStackTrace();  
}  
}  
}  
