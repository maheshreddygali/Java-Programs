import java.io.*;
class WriteText
{
public static void main(String[] args)
{
try
{
FileOutputStream fout = new FileOutputStream("sample text.txt");
String str = "This is gali mahesh";
byte b[] = str.getBytes();
fout.write(b);
fout.close();
System.out.println("Done...!!");
}
catch(Exception e)
{System.out.println(e);}
}
}
