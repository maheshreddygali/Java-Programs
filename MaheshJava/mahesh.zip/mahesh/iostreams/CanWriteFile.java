import java.io.*;  
public class CanWriteFile {  
public static void main(String[] args) 
{  
try 
{  
File file = new File("sample file.txt");  
file.createNewFile();
boolean f2 = file.canWrite();
System.out.println(f2); 

} 
catch (IOException e) 
{  
e.printStackTrace();  
}  
}  
}  
