
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileInputStream1
{
public static void main(String[] args) throws IOException
{
File file = new File("sample text.txt");
FileInputStream inputStream = new FileInputStream(file);
byte bytes[] = new byte[(int) file.length()];
int numOfBytes = inputStream.read(bytes);
System.out.println("Copied succesfully..!!");

}
}


 


