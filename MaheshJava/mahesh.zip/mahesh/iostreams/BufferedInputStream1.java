import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.*;

class BufferedInputStream1
{
public static void main(String[] args) throws IOException
{
File fi = new File("mahesh.txt");
FileInputStream file = new FileInputStream(fi);
BufferedInputStream bis = new BufferedInputStream(file);
int i;
{
while((i=bis.read())!= -1)
{
System.out.println((char)i);
}
bis.close();
file.close();
}

}
}
