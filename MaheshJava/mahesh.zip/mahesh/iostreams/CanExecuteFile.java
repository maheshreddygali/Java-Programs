import java.io.*;  
public class CanExecuteFile {  
public static void main(String[] args) 
{  
try 
{  
File file = new File("sample file.txt");  
file.createNewFile();

boolean f3 = file.canExecute();

System.out.println(f3); 
} 
catch (IOException e) 
{  
e.printStackTrace();  
}  
}  
}  
