import java.io.File;

import java.io.*;
import java.io.IOException;

class BufferedOutputStream1
{
public static void main(String[] args) throws IOException
{
FileOutputStream file = new FileOutputStream("mahesh.txt");
BufferedOutputStream bos = new BufferedOutputStream(file);
bos.write("This is gali mahesh".getBytes());
bos.close();
}
}
