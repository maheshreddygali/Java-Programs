class CompareStr
{
public static void main(String[] args)
{
String str1 = "mahesh gali";
String str2 = "mahesh gali";
System.out.println(str1.equals(str2));
}
}

