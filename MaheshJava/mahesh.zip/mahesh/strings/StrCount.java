class StrCount
{
public static void main(String[] args)
{
int count=0;
String str = "mahesh gali";
for(i=0;i<=str.length();i++)
{
str.charAt(i);
count++;
}
}}
