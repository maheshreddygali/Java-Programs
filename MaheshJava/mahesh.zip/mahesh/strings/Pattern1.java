class Pattern1
{
public static void main(String[] args)
{
int num;
for(int i=1;i<5;i++)
{
num = (int)Math.pow(11,i);
System.out.println(num);
}
}
}
