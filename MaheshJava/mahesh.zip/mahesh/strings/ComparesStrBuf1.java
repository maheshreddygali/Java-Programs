class ComparesStrBuf1
{
public static void main(String[] args)
{
StringBuffer sb1 = new StringBuffer("mahesh");
StringBuffer sb2 = new StringBuffer("mahesh");
System.out.println(sb1==sb2);

}
}
