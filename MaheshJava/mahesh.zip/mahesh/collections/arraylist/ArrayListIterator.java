import java.util.*;
class ArrayListIterator
{
public static void main(String[] args)
{
ArrayList<String> alist = new ArrayList<String>();
alist.add("Gali");
alist.add("Soma");
alist.add("Naga");
alist.add("Maheswar");
alist.add("Reddy");

for(String str : alist)
System.out.println(str);
}
}
