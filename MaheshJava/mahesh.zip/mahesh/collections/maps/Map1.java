import java.util.*;
class Map1
{
public static void main(String[] args)
{
Map map = new HashMap();
map.put(1,"Gali");
map.put(2,"Soma");
map.put(3,"Naga");
map.put(4,"Maheswar");
map.put(5,"Reddy");
System.out.println(map);
System.out.println(map.entrySet());
//System.out.println();

}
}
