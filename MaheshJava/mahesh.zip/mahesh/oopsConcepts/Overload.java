class Addition
{
static int add(int a, int b)
{
return a+b;
}

static double add(double x, double y)
{
return x+y;
}
}

class Overload
{
public static void main(String[] args)
{

System.out.println(Addition.add(2,5));
System.out.println(Addition.add(3.5,6.7));
}
}
