class MethodOverload
{
public void m1()
{
System.out.println("no-arg methods");
}
public void m1(int i)
{
System.out.println("int-arg methods");
}
public void m1(double d)
{
System.out.println("double-arg methods");
}
public static void main(String[] args)
{
MethodOverload obj = new MethodOverload();
obj.m1();
obj.m1(10);
obj.m1(14.898);
obj.m1('c');
}
}
