class A
{
public void m1()
{
System.out.println("parent class method m1");
}
public void m2()
{
System.out.println("parent class second method m2");
}
}

class B extends A
{
public void m1()
{
System.out.println("child class method m3");
}
}

class Override
{
public static void main(String[] args)
{
//A obj1 = new A();
//obj1.m1();
//obj1.m2();

//B obj2 = new B();
//obj2.m1();
//obj2.m2();
//obj2.m3();

A obj3 =new B();
obj3.m1();
}
}

