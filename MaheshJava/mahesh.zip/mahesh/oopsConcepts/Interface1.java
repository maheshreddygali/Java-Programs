interface A
{
void m1();
}

interface B extends A
{
void m2();
}

class C implements B
{
public void m1()
{
System.out.println("Class A :non abstract method m1");
}
public void m2()
{
System.out.println("Class B : non abstract method m2");
}
}

class Interface1 extends C
{
public static void main(String[] args)
{
C obj = new C();
obj.m1();
obj.m2();
}
}
