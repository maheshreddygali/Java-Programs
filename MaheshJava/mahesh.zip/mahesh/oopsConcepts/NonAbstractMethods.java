abstract class A
{
public void m1()
{
System.out.println("Class A :non abstract method m1");
}
}

abstract class B extends A
{
public void m2()
{
super.m1();
System.out.println("Class B : non abstract method m2");
}
}


class NonAbstractMethods extends B
{
public static void main(String[] args)
{
NonAbstractMethods obj = new NonAbstractMethods();
obj.m1();
obj.m2();
}
}
