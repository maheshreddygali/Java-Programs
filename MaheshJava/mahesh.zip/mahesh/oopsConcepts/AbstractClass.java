abstract class A
{
abstract void m1();
public void m2()
{
System.out.println("non abstract method m2");
}
}

abstract class B extends A
{
abstract void m3();
public void m4()
{
System.out.println("non-abstract method m4 class B");
}
}

class C extends B
{
void m1()
{
System.out.println("abstract method m1 class A");
}
void m3()
{
System.out.println("abstract method m3 class B");
}
}

class AbstractClass
{
public static void main(String args[])
{
C obj = new C();
obj.m1();
obj.m2();
obj.m3();
}
}
