import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbDemoProgram {

    public static void main(String args[ ])

    {
    try
     {
    Connection con=null;
    System.out.print("Loading Driver ..... ");
    Class.forName("com.ibm.db2.jcc.DB2Driver");
    System.out.println("Driver Class OK ");
    System.out.print("Getting Connection ..... ");
    con=DriverManager.getConnection("jdbc:db2://172.17.0.142:50001/itgdb","ITGUSR11","miracle11");
    System.out.println(" Connections OK ");
    Statement st=con.createStatement();
    String a="insert into shanm values ('chandu','ssss')";
    int d=st.executeUpdate(a);
    ResultSet s=st.executeQuery("select * from shanm");
    System.out.println(s);
    while(s.next()){
    System.out.println(s.getString("id")+"   "+s.getString("name"));
    }
    con.close( );
    }
    catch(ClassNotFoundException ex)
    {
     System.out.println("Driver Not Loaded");
    }
    catch(SQLException ex)
    {
    System.out.println("SQL Error: "+ex);
    }
    }
    }
