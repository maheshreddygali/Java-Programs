import java.io.*;  
public class FileNotFound {  
public static void main(String args[])
{    
try
{    
FileInputStream fin=new FileInputStream("mahesh.txt");         
}
catch(Exception e)
{
System.out.println(e);
}    
System.out.println("Done...!!");
}    
} 
