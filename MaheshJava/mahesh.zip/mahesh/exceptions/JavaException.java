public class ArithException
{  
public static void main(String args[])
{  
try
{  
int data=100/0;  
}
catch(ArithmeticException e)
{
System.out.println("divide by zero is not possible"+" "+e);
}  
System.out.println("rest of the code...");  
}  
}  
