import java.util.*;
import java.io.*;
public class MultiTryCatchBlock
{  
public static void main(String args[])
{  
try
{
System.out.println("First Try-Catch block");
System.out.println("enter any two numbers : ");  
Scanner sc = new Scanner(System.in);
int a = sc.nextInt();
int b = sc.nextInt();

int c=a/b;
System.out.println(c);  
}
catch(ArithmeticException e)
{
System.out.println("divide by zero is not possible"+" "+e);
System.out.println("Try Agaiin Later...!!");
}  



try
{
System.out.println("Second Try-Catch block");
System.out.println("enter any two numbers : ");  
Scanner sc = new Scanner(System.in);
int num1 = sc.nextInt();
int num2 = sc.nextInt();

int c=num1/num2;
System.out.println(c);  
}
catch(ArithmeticException e)
{
System.out.println("divide by zero is not possible"+" "+e);
System.out.println("Try Agaiin Later...!!");
}
System.out.println("Done...");    
}  
}  
