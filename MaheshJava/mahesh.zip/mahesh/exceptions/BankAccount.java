import java.util.*;
import java.io.*;
class BankAccount
{
public static void main(String[] args)
{
int balance = 10000000;
System.out.println("Enter your username : ");
Scanner sc = new Scanner(System.in);
String username = sc.nextLine();
System.out.println("Enter your password : ");
String password = sc.nextLine();
int user_choice = 2;
while(user_choice !=5)
{
System.out.println("1.Withdrawl Amount");
System.out.println("2.Deposite Amount");
System.out.println("3.View Balance");
System.out.println("4.exit()");
System.out.println("Enter your choice : ");
user_choice = sc.nextInt();
switch(user_choice)
{
case 1 :System.out.println("Enter the amount to be withdrawl : ");
	int amntwithdraw = sc.nextInt();
	if(amntwithdraw > balance) 
	{
	System.out.println("Withdrawl denied..!! please try again later..!!");
	}
	else
	{
	System.out.println("Withdrawl amount is : "+amntwithdraw+" "+"Remaining Balance : "+(balance-amntwithdraw));	
	}
	break;

case 2 :System.out.println("Enter the amount to be deposited : ");
	int depositamnt = sc.nextInt();
	if(depositamnt < 500)
	{
	System.out.println("please deposit more than 500 rupees..!!");
	}
	else
	{
	System.out.println("Deposited amount is : "+depositamnt+" "+"Remaining balance : "+(balance+depositamnt));
	}
	break;

case 3 ://System.out.println("please enter username : ");
	String user = "mahesh";
	user.equals(username);
	System.out.println("Total balance is : "+balance);
	break;

case 4 :System.out.println("Thank you...!!");
	break;
default : System.out.println("Please choose correct option...!!");
	 break;
}
}
}
}
