import java.io.*;
class ThrowsException
{
public static void fileEx() throws IOException
{
File f = new File("mahesh.txt");
FileInputStream stream = new FileInputStream(f);
}

public static void main(String[] args)
{
try
{
fileEx();
}
catch(Exception e)
{
System.out.println("file found exception"+" "+e);
}

finally
{System.out.println("hello");}
}
}

