import java.io.*;
import java.util.*;
class MultiCatch
{
public static void main(String[] args)
{

try
{
System.out.println("enter any two numbers : ");  
Scanner sc = new Scanner(System.in);
int a = sc.nextInt();
int b = sc.nextInt();
int c=a/b;
System.out.println(c); 
}

catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("array out of bound exception raised");
}

catch(ArithmeticException e)
{
System.out.println("arithmetic excepiton raised");
}

catch(Exception e)
{
System.out.println("default catch block");
}

finally
{
System.out.println("inside the finally block");
}
System.out.println("this is done..!!");
}
}
