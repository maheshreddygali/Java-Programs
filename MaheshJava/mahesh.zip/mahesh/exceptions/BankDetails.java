import java.io.*;
import java.util.*;

class MyException extends Exception
{
		MyException(String message)
	{
		super(message);
	}
}

public class BankDetails
{
	public static void main(String[] args) throws MyException
	{	
	try
	{
		String username,password;
		int balance = 2000000,a=0,d=2,noofwithdraw=0;
		boolean user_choice = true;
		Scanner sc = new Scanner(System.in);
		while(a<=2)
		{
			System.out.println("Enter your username : ");
			username = sc.nextLine();
			System.out.println("Enter your password : ");
			password = sc.nextLine();

	if(username.equals("mahesh")&&password.equals("mahesh123"))
	{
		while(user_choice)
		{
		System.out.println(" ");
		System.out.println("welcome to the ATM");
		System.out.println(" ");
		System.out.println(" 1.Withdraw \n 2.Deposit \n 3.View Balance \n 4.Exit \n\n !!...Enter your choice...!!");
		int choice = sc.nextInt();
		System.out.println(" ");
		switch(choice)
		{
		case 1 :if(noofwithdraw>=3)
				{
					System.out.println("Daily withdrawl limit is only 3 times...!! please try again later...!!!");
				}
			else
			System.out.println("Enter amount withdraw your amount : ");
			int withdraw = sc.nextInt();
			{
			
			if(withdraw > balance)
				{
					throw new MyException("enter valid withdrawl amount..!! makesure your current balance...!!!");
				}
			else if(withdraw>100000)
				{
					throw new MyException("you are not eligible to withdrw more than 1,00,000 rupees per day...!!");
				} 
			else
				{
					System.out.println("Withdrawl amount is : "+withdraw+" "+"your total balance is : "+(balance-withdraw));
					
				}
				noofwithdraw++;
			}
			
			
			break;
	
		case 2 :System.out.println("Welcome to deposit section..!!");
			System.out.println("enter amount to be deposit : ");
			int deposit = sc.nextInt();
			try
			{
			if(deposit<500 && deposit>100000)
				{
					System.out.println("Deposited amount is : "+deposit+" "+"total balance is : "+(deposit+balance));
				}
			else
				{
					throw new MyException("Minimum deposit amount is 500 rupees..!! please try again later...!!");
					
				}
			}
			catch(MyException e)
			{
				System.out.println(e);
				System.out.println("Transaction failed...!!!");
				//choice=false;				
			}
			break;
		
		case 3 :System.out.println("welcome to your current balance...!!");
			System.out.println("enter username : ");
			username = sc.next();
			System.out.println("enter password : ");
			password = sc.next();
			if(username.equals("mahesh")&&password.equals("mahesh123"))
			{
				System.out.println("Your current account balance is : "+balance);
			}
			else
			{
				System.out.println("Please enter valid credentitals...!!!");
			}
			break;
		case 4 :throw new MyException("user exit");
		}
		}}
		
	else 
	{	
		if(a!=3)
		{
	
			System.out.println("you have "+ d +"attempts...!! \n !!!...please enter valid password...!!!");
			d--;
			a++;	
		}
	}

}}
catch(Exception e)
{
System.out.println(e);
System.out.println("!!...Thanks for using ATM...!!");
}
}
}
