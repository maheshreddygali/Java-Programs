class MultiTryBlock
{
public static void main(String[] args)
{
try
{

	try
	{
			int c = 10/0;
			System.out.println("first try block");
	}
	catch(ArithmeticException e)
	{
		System.out.println("First try catch block : "+e);
	}

		try
		{
			int d = 20/5;
			System.out.println("Second try block : "+d);
		}
		catch(ArithmeticException e)
		{
			System.out.println("second try catch block : "+e);
		}
	}

catch(Exception e)
{
	System.out.println("first catch block : "+e);
}
System.out.println("hi");
}
}
