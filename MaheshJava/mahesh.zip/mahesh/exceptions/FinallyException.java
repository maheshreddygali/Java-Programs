import java.io.*;
import java.util.*;
class FinallyException
{
public static void main(String[] args)
{

try
{
System.out.println("enter any two numbers : ");  
Scanner sc = new Scanner(System.in);
int a = sc.nextInt();
int b = sc.nextInt();
int c=a/b;
System.out.println(c); 
}

catch(ArithmeticException e)
{
System.out.println("excepiton raised");
}

finally
{
System.out.println("inside the finally block");
}
System.out.println("this is done..!!");
}
}
