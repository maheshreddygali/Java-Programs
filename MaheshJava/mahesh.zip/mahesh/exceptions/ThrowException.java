import java.util.*;
class ThrowException
{
public void CheckAge()
{
System.out.println("enter age : ");
Scanner sc = new Scanner(System.in);
int age = sc.nextInt();
if(age<18)
{
System.out.println("access denied : not eligible to vote");
}
else
{
System.out.println("accesss accepted : eligible to vote");
}
}

public static void main(String[] args)
{
ThrowException f = new ThrowException();
f.CheckAge();
System.out.println("helo...!!!");
}
}

