import java.io.FileInputStream;  
public class Mahesh {  
public static void main(String args[])
{    
try
{    
FileInputStream fin=new FileInputStream("mahesh.txt");         
}
catch(Exception e)
{
System.out.println(e);
}    
}    
} 
