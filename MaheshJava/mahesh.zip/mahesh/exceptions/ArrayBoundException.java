import java.io.*;
class ArrayBoundException
{
public static void main(String[] args)
{
try
{
int arr[] = new int[5];
arr[0]=1;
arr[1]=2;
arr[2]=3;
arr[3]=4;
arr[4]=5;
System.out.println("array index number is : "+arr[7]);
}

catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("entered index number is out of bound");
}
System.out.println("Done...!!");
}
}
