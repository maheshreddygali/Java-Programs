import java.util.*;
class Ex36
{
 public static void main(String args[])
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter your initial");
  char YourFirstInitial =sc.next().charAt(0);
  System.out.println("Your First Initial is:"+YourFirstInitial);
 }
}
