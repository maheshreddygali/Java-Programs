import java.util.*;
class Ex35
{
 public static void main(String args[])
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter the number");
  int YourSalary=sc.nextInt();
  System.out.println("Your salary amount is:"+YourSalary);
 }
}
