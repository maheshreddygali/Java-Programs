import java.util.*;
class Ex11
{
 public static void main(String args[])
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter a digit");
  int d=sc.nextInt();
  System.out.println("Enter a character");
  char c=sc.next().charAt(0);
  System.out.println(d+"   "+c);
 }
}
