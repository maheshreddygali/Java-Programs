class Ex26
{
 public static void main(String args[])
 {
  for(int i=97;i<=122;i++)
   {
    char c=(char)i;
    System.out.print(c);
   }
 }
}
