import java.util.*;
class Ex37
{
 public static void main(String args[])
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter hour value");
  int h=sc.nextInt();
  int s=3600*h;
  System.out.println(s);
 }
}
