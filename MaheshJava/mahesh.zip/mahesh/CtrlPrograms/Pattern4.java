class Pattern4
{
 public static void main(String args[])
 {
  for(int i=1;i<=4;i++)
   {
    for(int j=4;j>=i;j--)
     System.out.print(" ");
    for(int k=i;k>0;k--)
     System.out.print(k);
    for(int x=2;x<=i;x++)
     System.out.print(x);
    System.out.println();
   }
 }
}
